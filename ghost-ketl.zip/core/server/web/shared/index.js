module.exports = {
    get middleware() {
        return require('./middleware');
    }
};
